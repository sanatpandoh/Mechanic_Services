<?php
require_once("../includes/session.php"); 
require_once("../includes/database.php"); 
require_once("../includes/function.php");


if(!isset($_GET['status']) || !isset($_GET['request'])) {
	redirect_to("admin_index.php");
}

if($_GET['status'] == 1) {
	$status= "accepted";
} elseif($_GET['status'] == 0) {
	$status= "rejected";
} else {
	redirect_to("mechanic_requests.php");
}

$request_id= $_GET['request'];

$query= "UPDATE mechanics SET status= '$status' WHERE id= $request_id LIMIT 1 ";
$result= mysqli_query($connection, $query);

if($result) {
	$_SESSION['message']= "Mechanics Updated Successfully";
	redirect_to("admin_index.php");
}

?>