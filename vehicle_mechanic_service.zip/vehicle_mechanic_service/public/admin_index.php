<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/database.php"); ?>
<?php require_once("../includes/function.php"); ?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Index</title>
	<link rel="stylesheet" href="stylesheets/w3schools_com_lib_w3.css">
</head>
<body bgcolor=#ecf0f1 text=black><br>

<?php
if(!isset($_SESSION['admin_id'])) {
	redirect_to("index.php");
} 

$user_id= $_SESSION['admin_id'];
$name= find_name_by_id("users", $user_id);?>

<div align="center"><h2><b>Welcome, <?php echo $name; ?></h2></b></div><br><br>


	<div align="center">
<a href="all_mechanics_request.php" class="w3-btn-block w3-black">New Mechanics Requests</a><br><br><br>
<a href="accepted_mechanics.php" class="w3-btn-block w3-black">Accepted Mechanics</a><br><br><br>
<a href="rejected_mechanics.php" class="w3-btn-block w3-black">Rejected Mechanics</a>
	</div>
</body>
</html>