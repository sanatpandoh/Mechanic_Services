<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/database.php"); ?>
<?php require_once("../includes/function.php"); ?>
<?php confirm_logged_in(); ?>

<!DOCTYPE html>
<html>
<head>
	<title>Mechanic Index</title>
	<link rel="stylesheet" href="stylesheets/w3schools_com_lib_w3.css">
</head>
<body><br>
<?php
$mechanic_id= $_SESSION['admin_id'];
$name= find_name_by_id("mechanics", $mechanic_id);?>

<div align="center"><h2><b>Welcome, <?php echo $name; ?></h2></b></div><br><br>

	<div align="center">
<a href="mechanic_requests.php" class="w3-btn-block w3-black">All Requests</a><br><br><br>
<a href="accepted_requests.php" class="w3-btn-block w3-black">Accepted Requests</a>
	</div>
</body>
</html>