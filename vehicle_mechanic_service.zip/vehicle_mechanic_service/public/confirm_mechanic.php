<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/database.php"); ?>
<?php require_once("../includes/function.php"); ?>


<?php

if(!isset($_GET)) {
	redirect_to("admin_index.php");
}

$request= $_GET['request'];
$status= $_GET['status'];


$query= "UPDATE mechanic_request SET status = 'accepted' WHERE id= $request ";
$result= mysqli_query($connection, $query);



?>