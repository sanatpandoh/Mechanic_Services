<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/database.php"); ?>
<?php require_once("../includes/function.php"); ?>
<?php confirm_logged_in(); ?>

<!DOCTYPE html>
<html>
<head>
	<title>User Index</title>
	<link rel="stylesheet" href="stylesheets/w3schools_com_lib_w3.css">
</head>
<body bgcolor=#ecf0f1 text=black><br>

<?php

$user_id= $_SESSION['admin_id'];
$name= find_name_by_id("users", $user_id);?>

<div align="center"><h2><b>Welcome, <?php echo $name; ?></h2></b></div><br><br>


	<div align="center">
<a href="make_request.php" class="w3-btn-block w3-black">Sos Button</a><br><br><br>
<a href="user_request.php" class="w3-btn-block w3-black">My Requests</a>
	</div>
</body>
</html>