<?php
require_once("../includes/session.php"); 
require_once("../includes/database.php"); 
require_once("../includes/function.php");


if(!isset($_GET['status']) || !isset($_GET['status'])) {
	redirect_to("mechanic_requests.php");
}

if($_GET['status'] == 1) {
	$status= "accepted";
} elseif($_GET['status'] == 0) {
	$status= "rejected";
} else {
	redirect_to("mechanic_requests.php");
}

$request_id= $_GET['request_id'];
$request_no= $_GET['request_no'];

if($status == "accepted") {

	$query= "UPDATE requests SET status= 'rejected' WHERE request_no= $request_no ";
	$result1= mysqli_query($connection, $query);

	$query= "UPDATE requests SET status= 'accepted' WHERE id= $request_id ";
	$result= mysqli_query($connection, $query);

	if($result && $result1) {
		$_SESSION['message']= "Request Accepted Successfully";
		redirect_to("accepted_requests.php");
	}

} elseif($status == 'rejected') {

	$query= "UPDATE requests SET status= 'rejected' WHERE request_id= $request_id ";

	$result= mysqli_query($connection, $query);

	if($result) {
		$_SESSION['message']= "Request Rejected Successfully";
		redirect_to("mechanic_requests.php");
	}

}


?>