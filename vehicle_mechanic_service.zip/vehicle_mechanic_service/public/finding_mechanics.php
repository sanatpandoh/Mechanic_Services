<?php

require_once("../includes/session.php"); 
require_once("../includes/function.php");

if(!isset($_POST['Submit'])) {
	redirect_to("make_request.php");
}

print_r($_POST);
exit();

$vehicle_number= $_POST['vehicle_number'];
$vehicle= $_POST['vehicle'];
$issue= $_POST['issue'];

$vehicle_values= "&vehicle_number=" . $vehicle_number . "&issue=" . $issue . "&vehicle=".$vehicle.;

if(!isset($_SESSION['admin_id'])) {
	redirect_to("index.php");
}


?>