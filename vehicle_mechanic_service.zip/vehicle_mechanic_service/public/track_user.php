<?php
require_once("../includes/session.php"); 
require_once("../includes/database.php"); 
require_once("../includes/function.php");
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="initial-scale=1.0, user-scalable=no"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>

<link href="http://code.google.com/apis/maps/documentation/javascript/examples/default.css" rel="stylesheet" type="text/css" />

<script async src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCc7FZQ6jG2VcxnxbMNdkPFFzrUsJxq-ys&callback=getLocation"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>


<script type="text/javascript">
  var lat1;
  var long1;

  $.get("https://api.ipdata.co?api-key=d8ab8ec0de00ad71ba982489bcfdfbd47c113200a429758e4fa3fc75", function (response) {

  lat1= response.latitude;
  long1= response.longitude;
  lat2= document.getElementById("lat2").innerHTML;
  long2= document.getElementById("long2").innerHTML;

}, "jsonp");

  var directionDisplay;
  var directionsService = new google.maps.DirectionsService();
  var map;

  function initialize() {
    directionsDisplay = new google.maps.DirectionsRenderer();
    var myOptions = {
      mapTypeId: google.maps.MapTypeId.ROADMAP,
    }
    map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
    directionsDisplay.setMap(map);

    var start = lat1 + ", " + long1;
    var end = lat2 + ", " + long2;
    var request = {
      origin:start, 
      destination:end,
      travelMode: google.maps.DirectionsTravelMode.DRIVING
    };
    directionsService.route(request, function(response, status) {
      if (status == google.maps.DirectionsStatus.OK) {
        directionsDisplay.setDirections(response);
        var myRoute = response.routes[0];
        var txtDir = '';
        for (var i=0; i<myRoute.legs[0].steps.length; i++) {
          txtDir += myRoute.legs[0].steps[i].instructions+"<br />";
        }
        document.getElementById('directions').innerHTML = txtDir;
      }
    });
  }
</script>
</head>

<body onload="initialize()">

<?php 
$latitude= $_GET['latitude'];
$longitude= $_GET['longitude'];
$request_id= $_GET['request'];
$user_id= $_GET['user'];

$user= find_user_by_id($user_id);

?>
<div style="display: none;">
<span id="lat2"><?php echo $latitude; ?></span>
<span id="long2"><?php echo $longitude; ?></span>
</div>

<div style="background-color: black; color: white;">
  
  <b>Name: &nbsp;&nbsp;&nbsp;</b> <?php echo $user['name']; ?><br><br>
  <b>Address: &nbsp;&nbsp;&nbsp;</b> <?php echo $user['address']; ?><br><br>
  <b>Contact: &nbsp;&nbsp;&nbsp;</b> <?php echo $user['mobile_number']; ?><br><br>
</div>
<br><br><br>
<div id="directions" style="width:500px;height:500px;float:left"></div>
<div id="map_canvas" style="width:500px;height:500px;"></div>
</body>
</html>

