<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript">
$.get("https://api.ipdata.co?api-key=d8ab8ec0de00ad71ba982489bcfdfbd47c113200a429758e4fa3fc75", function (response) {
	
	city= response.city;
	region= response.region;
	latitude= response.latitude;
	longitude= response.longitude;
	postal= response.postal;

	$link= "register_mechanic.php?city=" + city + "&region=" + region + "&latitude=" + latitude + "&longitude="+ longitude + "&postal=" + postal + "&set=1";
	window.location.replace($link);
}, "jsonp");
</script>