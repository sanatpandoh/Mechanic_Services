<?php 

require_once("../includes/session.php");  
require_once("../includes/database.php"); 
require_once("../includes/function.php"); 

?>

<?php

if(isset($_POST['submit2'])) {
	$real_otp= $_POST['real_otp'];
	$otp= $_POST['otp'];
	$contact= $_POST['contact'];

	if($real_otp == $otp) {
		$_SESSION['contact']= $contact;
		header("Location: register_mechanic.php"); 
	} else {
		$_SESSION['message']= "!! Wrong Otp Entered !!";
		header("Location: get_mechanic_contact.php");
	}
}


if(isset($_POST['submit1'])) {
	$contact= $_POST['contact'];
	$contact= "+91" . $contact;

	$real_otp= rand(100000, 999999); 
	$otp= "Otp for vehicle mechanic service is " . $real_otp; 
	//echo $otp;
	send_sms($otp, $contact); ?>

<!DOCTYPE html>
<html>
<head>
	<title>New User</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body bgcolor=#ecf0f1 text=black class="w3-center">

	<form action="get_mechanic_contact.php" method="post"  class="w3-container w3-card-4 w3-light-grey w3-text-red w3-margin">
	<h2 class="w3-center">Register Contact</h2>

	<br><br>
	
	<input type="hidden" name="real_otp" value="<?php echo $real_otp; ?>">
	<input type="hidden" name="contact" value="<?php echo $contact; ?>">

	Enter Otp:&nbsp;&nbsp;<input type="text" name="otp"  required><br><br>

	<input type="submit" name="submit2" value="Submit">
	</form>

</body>
</html>

<?php }  ?>

<?php if(empty($_POST)) { ?>
<!DOCTYPE html>
<html>
<head>
	<title>New User</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body bgcolor=#ecf0f1 text=black class="w3-center">

	<form action="get_mechanic_contact.php" method="post"  class="w3-container w3-card-4 w3-light-grey w3-text-red w3-margin">
	<h2 class="w3-center">Register Contact</h2>

	<br><br>

	Contact:&nbsp;&nbsp;+91&nbsp;&nbsp;&nbsp;	<input type="text" name="contact"  required><br><br>

	<input type="submit" name="submit1" value="Submit">
	</form>
<br><br><br>

<div class="w3-center" style="color: red; "><?php if(isset($_SESSION['message'])) { echo $_SESSION['message']; $_SESSION['message']= ""; } ?></div>
</body>
</html>

<?php } ?>