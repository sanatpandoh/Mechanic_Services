<?php
require_once("../includes/session.php"); 
require_once("../includes/database.php"); 
require_once("../includes/function.php");
confirm_logged_in();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Confirm Mechanic</title>
	<link rel="stylesheet" href="stylesheets/w3schools_com_lib_w3.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body bgcolor=#ecf0f1 text=black >



<br><br>
<div align="center">
<form action="find_mechanics.php" method="post"  class="w3-container w3-card-4 w3-light-grey w3-text-red w3-margin">
<h2 class="w3-center"> VEHICLE DETAILS:</h2>	
	Vehicle Details:&nbsp;&nbsp;<input type="text" name="vehicle"><br><br><br>

	Vehicle Number:&nbsp;&nbsp;<input type="text" name="vehicle_number"><br><br><br>

	Issues: &nbsp;&nbsp;<input type="text" name="issue"><br><br>
	<br>
	<input type="submit" name="Submit" value="Submit" class="w3-btn w3-white"><br>

</form>

</div>

</body>
</html>