<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/database.php"); ?>
<?php require_once("../includes/function.php"); ?>

<!DOCTYPE html>

<html>
<title>Login</title>

<link rel="icon" href="images/logo_new.png" type="image/x-icon">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="stylesheets/w3schools_com_lib_w3.css">

<body bgcolor=#ecf0f1 text=black>

<?php

	if( isset($_POST["submit"]) ) {

    $username= mysqli_real_escape_string($connection, $_POST["username"]);

  	$password= mysqli_real_escape_string($connection, $_POST["password"]);

    $found_admin= attempt_login($username, $password);
	
	

    if($found_admin) {
    	
       $_SESSION["admin_id"]= $found_admin["admin_id"];
       $_SESSION["status"]= $found_admin["status"];
        
        if($found_admin['status'] == 'user' ) {
        redirect_to("user_index.php");
       } 
	   
	   elseif($found_admin['status'] == 'admin') {
          redirect_to("admin_index.php");
       } else {
        
        $id= $found_admin['admin_id'];
        $query= "SELECT status FROM mechanics WHERE id= $id LIMIT 1";
        $result= mysqli_query($connection, $query);

        if($status_set= mysqli_fetch_assoc($result)) {
          $status= $status_set['status'];

          if($status== 'accepted') {
            redirect_to("mechanic_index.php");
          } else {
            $_SESSION['message']= "Your account is still not accepted !!";
            redirect_to("index.php");
          }
        }
      }      
	   
	} else {
        $_SESSION["message"]= "Wrong Password !!";
      }
	 
}
?>

<div id="id01" class="w3-modal" style="display: block;">
    
    <div class="w3-modal-content w3-card-8 w3-animate-zoom" style="max-width:600px">
  
      <div class="w3-center"><br>
        
        <a href="index.php"><span class="w3-closebtn w3-hover-red w3-container w3-padding-8 w3-display-topright" title="Close Modal">×</span></a>
        
        <img src="images/logo.jpeg" alt="Avatar" style="width:30%" class="w3-circle w3-margin-top">

      </div>

      <form class="w3-container" action="index.php" method="post">
        <div class="w3-section">
              <br><br>

              <b> <?php if($output = message()) { echo $output; } ?></b>
            
            </div><br>


        <label><b>Username</b></label>

          <input class="w3-input w3-border" type="text" placeholder="Enter Username" name="username" value="" required><br>


          <label><b>Password</b></label>

          <input class="w3-input w3-border" type="password" placeholder="Enter Password" name="password" value="" required>
          
          <button class="w3-btn-block w3-green w3-section w3-padding" type="submit" name="submit" >Login</button>
          
          <div id="login_error" ><?php echo message(); ?></div>
          
        <input class="w3-check w3-margin-top" type="checkbox" checked="checked"> Remember me

        <a class="w3-check w3-margin w3-right" href="home.php" target="_blank"> New User  </a>

        </div>
      </form>


    </div>
  </div>
            
</body>
</html>