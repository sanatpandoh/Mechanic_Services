<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/database.php"); ?>
<?php require_once("../includes/function.php"); ?>

<?php

if(!isset($_SESSION['contact'])) {
	redirect_to('get_mechanic_contact.php');
}


if(isset($_POST['submit'])) {

	$name= $_POST['name'];
	$company= $_POST['company'];
	$speciality= $_POST['speciality'];
	$contact= $_SESSION['contact'];
	$username= $_POST['username'];
	$password= $_POST['password'];

	$city= $_POST['city'];
	$region= $_POST['region'];
	$latitude= $_POST['latitude'];
	$longitude= $_POST['longitude'];
	$postal= $_POST['postal'];

$query= "INSERT INTO mechanics (name, company, speciality, contact, city, region, latitude, longitude, postal, status) VALUES ";
$query.= "('$name', '$company', '$speciality', '$contact', '$city', '$region', '$latitude', '$longitude', '$postal', 'waiting') ";

$result1= mysqli_query($connection, $query);

$admin_id= mysqli_insert_id($connection);

$query= "INSERT INTO login (admin_id, username, hashed_password, status) ";
$query.= "VALUES ($admin_id, '$username', '$password', 'mechanic' )";

$result2= mysqli_query($connection, $query); 


if($result1 && $result2) {
	redirect_to("index.php");
} else {
	print_r("Something went wrong");
	exit();
}

}

  if(!isset($_GET['set'])) {
	redirect_to("return_location.php");
}

  $city= $_GET['city'];
$region= $_GET['region'];
$latitude= $_GET['latitude'];
$longitude= $_GET['longitude'];
$postal= $_GET['postal'];


?> 



<!DOCTYPE html>
<html>
<head>
	<title>New User</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body bgcolor=#ecf0f1 text=black class="w3-center">

	<form action="register_mechanic.php" method="post"  class="w3-container w3-card-4 w3-light-grey w3-text-red w3-margin">
	<h2 class="w3-center">REGISTER</h2>
	

	  <input type="hidden" name="city" value="<?php echo $city; ?>">
		<input type="hidden" name="region" value="<?php echo $region; ?>">
		<input type="hidden" name="latitude" value="<?php echo $latitude; ?>">
		<input type="hidden" name="longitude" value="<?php echo $longitude; ?>">
		<input type="hidden" name="postal" value="<?php echo $postal; ?>"> 


	Name:<br><input type="text" name="name" required><br><br></td>
	
	Company:<br><input type="text" name="company"  required><br><br></td>
	Speciality:	<br><input type="text" name="speciality"  required><br><br>
	Username:<br><input type="text" name="username"  required><br><br>
	Password:<br><input type="password" name="password"  required><br><br>

	<input type="submit" name="submit" value="Submit">

	</form>

</body>
</html>