<?php
require_once("../includes/session.php"); 
require_once("../includes/database.php"); 
require_once("../includes/function.php");
confirm_logged_in();

?>

<!DOCTYPE html>
<html>
<head>
	<title>User Requests</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body bgcolor=#ecf0f1 text=black class="w3-center">


<div class="w3-container">
  <h2>My Request</h2>
  <br>
<div class="w3-center w3-red">
  <?php

  if(isset($_SESSION['message']) && !empty($_SESSION['message'])) {
  	echo $_SESSION['message'];
  	$_SESSION['message']= "";
  }

  ?>
</div>
<br>
<table style="width: 100%;" border="1" align="center" class="w3-table-all w3-card-4">
	<tr>
		<th>Vehicle</th>
		<th>Issue</th>
		<th>Occurence</th>
		<th>Status</th>
		<th>&nbsp;</th></tr>

<?php 

$user_id= $_SESSION['admin_id'];


$request_set= find_user_request($user_id); 


while($request= mysqli_fetch_assoc($request_set)) {
	$request_id= $request['id'];
	$mechanic_id= $request['mechanic_id'];
	$latitude= $request['latitude'];
	$longitude= $request['longitude'];

	$values= "request=" . $request_id . "&mechanic=" . $mechanic_id . "&latitude=" . $latitude . "&longitude=" . $longitude; 

	echo "<tr align=\"center\">";
	echo "<td>" . $request['vehicle_number'] . "</td>";
	echo "<td>" . $request['issue'] . "</td>";
	echo "<td>" . $request['occurence'] . "</td>";
	echo "<td>" . $request['status'] . "</td>";	

	if($request['status'] == "accepted") {
	echo "<td><a href=\"track_mechanic.php?$values\">Track</a></td>";	
	} else {
		echo "<td>Blocked</td>"; 
	}
	echo "</tr>";
}

?>

</table></div>

</body>
</html>