<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/database.php"); ?>
<?php require_once("../includes/function.php"); ?>


<!DOCTYPE html>
<html>
<head>
	<title>ALL Mechanics</title>
</head>
<body>
<br><br><br>
<?php 

	
	if(!isset($_GET['set'])) {
		redirect_to("find_mechanics.php");
	}

	//print_r($_GET);

	$city= $_GET['city'];
	$region= $_GET['region'];
	$my_lat= $_GET['latitude'];
	$my_long= $_GET['longitude'];
	$user_id= $_SESSION['admin_id'];
	$issue= $_GET['issue'];
	$vehicle_number= $_GET['vehicle_number'];
	$vehicle= $_GET['vehicle'];


$mechanics_set= find_mechanics($city, $region); 
//print_r($mechanics_set);
//print_r($mechanics_set);

?>
<?php 
$count = 0;
$request_no= mt_rand();

	while($mechanic= mysqli_fetch_assoc($mechanics_set)) {

		//print_r($mechanic);
		//print_r($mechanic);

		$lat2= $mechanic['latitude'];
		$long2= $mechanic['longitude'];
		$distance= distance($my_lat, $my_long, $lat2, $long2, "K");


		//echo "Distance    :   ".  $distance; 
		
		if($distance < 20) {
			
			$contact= $mechanic['contact'];
			$mechanic_id= $mechanic['id'];

			$count+=1;

			$message= "You have some new user requests\n\n";
			
			//$message.= "http://findMechanic.site90.net/"; 
			send_sms($message, $contact);


			$query= "INSERT INTO requests (request_no, user_id, mechanic_id, issue, vehicle_number, vehicle, status, latitude, longitude) ";
			$query.= "VALUES ";
			$query.= "($request_no, $user_id, $mechanic_id, '$issue', '$vehicle_number', '$vehicle' ,'waiting', '$my_lat', '$my_long' )";

			echo $count . ".&nbsp;&nbsp;&nbsp;";

			//print_r($query);

			echo "<br><br><br>";
			$result= mysqli_query($connection, $query );

			if(!$result) {
				echo "Something Went Wrong ";
				exit();
			} else {
				//echo "Request Posted to " . $count . " mechanics";
				continue(1);
			}	

		}
	}

$_SESSION['message']= "Request Posted to " . $count . " mechanics";
redirect_to("user_request.php");

?>



</body>
</html>