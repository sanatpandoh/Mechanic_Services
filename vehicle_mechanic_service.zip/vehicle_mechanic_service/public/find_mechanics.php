<?php 
// print_r($_POST);
// exit();

require_once("../includes/session.php"); 
require_once("../includes/function.php");
confirm_logged_in();

if(!isset($_POST['Submit'])) {
	redirect_to("make_request.php");
}



$vehicle_number= $_POST['vehicle_number'];
$vehicle= $_POST['vehicle'];
$issue= $_POST['issue'];

$vehicle_values= "&vehicle_number=" . $vehicle_number . "&issue=" . $issue . "&vehicle=".$vehicle;

if(!isset($_SESSION['admin_id'])) {
	redirect_to("index.php");
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Sos Button</title>
</head>
<body>

<style>
.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript">

var link;

function make_redirect() {
	window.location.replace(link);
}

function start_timer() {
	setTimeout(make_redirect, 5000);
}

$.get("https://api.ipdata.co?api-key=d8ab8ec0de00ad71ba982489bcfdfbd47c113200a429758e4fa3fc75", function (response) {
	city= response.city;
	region= response.region;
	latitude= response.latitude;
	longitude= response.longitude;
	postal= response.postal;

	link= "all_mechanics.php?city=" + city + "&region=" + region + "&latitude=" + latitude + "&longitude="+ longitude + "&set=1<?php echo $vehicle_values; ?>";
	start_timer();
}, "jsonp");
</script>

<div align="center">
	
	<div class="loader" style="margin-top: 20%;"></div><br>
	<div><b><i>Finding Mechanics......</i></b></div>

</div>

</body>
</html>