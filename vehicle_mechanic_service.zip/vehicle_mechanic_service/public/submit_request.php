<?php
require_once("../includes/session.php"); 
require_once("../includes/database.php"); 
require_once("../includes/function.php");
 
$mechanic_id= $_POST['mechanic'];
$user_id= $_SESSION['admin_id'];
$issue= $_POST['issue'];
$vehicle_number= $_POST['vehicle_number'];

$query= "INSERT INTO requests (user_id, mechanic_id, issue, vehicle_number, status) ";
$query.= "VALUES ";
$query.= "($user_id, $mechanic_id, '$issue', '$vehicle_number', 'waiting' )";


$result= mysqli_query($connection, $query );

if(!$result) {
	echo "Something Went Wrong ";
	exit();
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Request</title>
</head>
<body bgcolor=#ecf0f1 text=black>

<h1>Your Request has been successfully sent.</h1>

<a href="return_directions.php?mechanic=<?php echo $mechanic_id; ?>">Get directions to Mechanic</a>


</body>
</html>