<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/database.php"); ?>
<?php require_once("../includes/function.php"); ?>

<?php


$query= "SELECT * FROM mechanics WHERE status= 'rejected' ";
$result_set= mysqli_query($connection, $query); ?>





<!DOCTYPE html>
<html>
<head>
	<title>Rejected Mechanics</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body bgcolor=#ecf0f1 text=black>
<div class="w3-container">
  <h2>List Of Rejected Mechanics</h2>
	<table border="1" class="w3-table-all w3-card-4">
		<tr>
			<th>Name</th>
			<th>Company</th>
			<th>Speciality</th>
			<th>Contact</th>
			<th>City</th>
			<th>Region</th>
			<th>Postcode</th>
		</tr>
	



<?php
while($result= mysqli_fetch_assoc($result_set)) {
	$id= $result['id'];
	$name= $result['name'];
	$company= $result['company'];
	$speciality= $result['speciality'];
	$contact= $result['contact'];
	$city= $result['city'];
	$region= $result['region'];
	$latitude= $result['latitude'];
	$longitude= $result['longitude'];
	$postal= $result['postal'];

	echo "<tr><td>$name</td>";
	echo "<td>$company</td>";
	echo "<td>$speciality</td>";
	echo "<td>$contact</td>";
	echo "<td>$city</td>";
	echo "<td>$region</td>";
	echo "<td>$postal</td>";
}


?>

</table>

</body>
</html>