<?php
require_once("../includes/session.php"); 
require_once("../includes/database.php"); 
require_once("../includes/function.php");
confirm_logged_in();
?>


<!DOCTYPE html>
<html>
<head>
	<title>All accepted requests</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body bgcolor=#ecf0f1 text=black class="w3-center">

<?php 
 $mechanic_id= $_SESSION['admin_id'];
 // print_r($mechanic_id);
//get this by login

$request_set= find_accepted_requests($mechanic_id); ?>


<div class="w3-container">
  <h2>All Accepted Requests</h2>
  <br>
  <div>
  	<?php if($_SESSION['message']) {
			echo $_SESSION['message'];
			$_SESSION['message']= ""; } ?>
  </div>
  <br>
<table style="width: 100%;" border="1" align="center" class="w3-table-all w3-card-4">
	<tr>
		<th>Name</th>
		<th>Issue</th>
		<th>Vehicle Number</th>
		<th>Occurence</th>
		<th>&nbsp;</th>
		<th>&nbsp;</th></tr>

<?php 


while($request= mysqli_fetch_assoc($request_set)) { 
$name= find_name_by_id("users", $request['user_id']);
$id= $request['id'];
$user_id= $request['user_id'];
$latitude= $request['latitude'];
$longitude= $request['longitude'];

$values= "request=" . $id . "&user=" . $user_id . "&latitude=" . $latitude . "&longitude=" . $longitude; 
?>

<tr align="center">
<td><?php echo $name; ?></td>
<td><?php echo $request['issue']; ?></td>
<td><?php echo $request['vehicle_number']; ?></td>
<td><?php echo $request['occurence']; ?></td>
<td><a href="track_user.php?<?php echo $values; ?>">Track</a></td>
<td><a href="mark_complete.php?request=<?php echo $id; ?>" onclick="return confirm("Are you Sure you are done with this vehicle...")">Mark Complete</a></td>
</tr>


<?php } ?>


</body>
</html>