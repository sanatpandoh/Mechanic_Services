<?php
require_once("../includes/session.php"); 
require_once("../includes/database.php"); 
require_once("../includes/function.php");

if(!isset($_GET['request'])) {
	redirect_to();
}

$request_id= $_GET['request'];

$query= "UPDATE requests SET status= 'Completed' WHERE id= $request_id ";

$result= mysqli_query($connection, $query);

if($result) {
	$_SESSION['message']= "LIST UPDATED ";
	redirect_to("accepted_requests.php");
}

?>