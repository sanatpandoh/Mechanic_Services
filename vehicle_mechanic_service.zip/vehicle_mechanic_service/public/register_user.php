<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/database.php"); ?>
<?php require_once("../includes/function.php"); ?>

<?php

if(isset($_POST['submit'])) {

	$name= $_POST['name'];
	$address= $_POST['address'];
	$contact= $_POST['contact'];
	$username= $_POST['username'];
	$password= $_POST['password'];


$query= "INSERT INTO users (name, address, mobile_number) VALUES ";
$query.= "('$name', '$address', '$contact') ";

$result1= mysqli_query($connection, $query);

$admin_id= mysqli_insert_id($connection);

$query= "INSERT INTO login (admin_id, username, hashed_password, status) ";
$query.= "VALUES ($admin_id, '$username', '$password', 'user' )";

$result2= mysqli_query($connection, $query); 


if($result1 && $result2) {
	redirect_to("index.php");
} else {
	print_r("Something went wrong");
	exit();
}

}


?>



<!DOCTYPE html>
<html>
<head>
	<title>New User</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body bgcolor=#ecf0f1 text=black>
	<form action="register_user.php" method="post" class="w3-container w3-card-4 w3-light-grey w3-text-red w3-margin">
<h2 class="w3-center">REGISTER</h2>
 

	
Name:		<input type="text"  name="name" required><br><br>
Address:	<input type="text" name="address" required><br><br>
Contact:	<input type="text" name="contact" required><br><br>
Username:	<input type="text" name="username" required><br><br>
Password:	<input type="password" name="password" required><br><br>


	<input type="submit" name="submit" value="Submit">

	</form>
</body>
</html>