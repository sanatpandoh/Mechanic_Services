<html>
<head>
<title>home</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->
</script>
<style>
    h2 
	{ color: blue; }
  </style>

</head>

<body  text=black alink=red vlink=red bgcolor=#ecf0f1 >


<div class="w3-container">
<h2>REGISTER</h2>

<table align="bottom" class="w3-table-all w3-card-4">


<tr >
<td bgcolor=#dac292 height="70" width="50"><center>New User </center></td>
<td  bgcolor=pink height="70" width="50"><center><a href="register_user.php" target="_blank">Register_user</center></td>
</tr>
<tr >
<td  bgcolor=#dac292  height="70" width="50"><center>New Mechanic</center></td>
<td bgcolor=pink height="70" width="50"><center><a href="get_mechanic_contact.php" target="_blank">Register_mechanic</center></td>
</tr>



<tr>
<td  bgcolor=#dac292  height="70" width="50"><center>Existing </center></td>
<td bgcolor=pink height="70" width="50"><center><a href="index.php" target="_blank">Login </center></td>
</tr>

</table>


</body>

</html>