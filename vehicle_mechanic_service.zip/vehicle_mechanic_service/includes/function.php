<?php

function confirm_query($result_set) {
	global $connection;
	if(!$result_set) {
		echo mysqli_errno($connection);
		echo mysqli_error($connection);
		die("Database query failed.");
	}
}

function redirect_to($new_location) {
	header("Location: ".$new_location);
	exit;
}


function attempt_login($username, $password) {

global $connection;

$safe_username= mysqli_real_escape_string($connection, $username);
$safe_password= mysqli_real_escape_string($connection, $password);

$query="SELECT * ";
$query.="FROM login ";
$query.="WHERE username= '{$safe_username}' AND hashed_password= '{$safe_password}' ";
$query.="LIMIT 1 ";
$user_set = mysqli_query($connection, $query);
confirm_query($user_set);

  if($user = mysqli_fetch_assoc($user_set)) {
  return $user; } else { return null; }
}

function logged_in() {
	if(isset($_SESSION['admin_id']) && isset($_SESSION['status'])) {
		return true;
	} else { return false; }
}

function confirm_logged_in() {	
	if(!logged_in()) {
		redirect_to("index.php");
	}
}

function find_mechanics($city, $region) {
	global $connection;

	$query= "SELECT * FROM mechanics WHERE region= '$region' ";
	$result_set= mysqli_query($connection, $query);

	if($result_set) { return $result_set; }
		return null;
}

function distance($lat1, $lon1, $lat2, $lon2, $unit) {
  if (($lat1 == $lat2) && ($lon1 == $lon2)) {
    return 0;
  }
  else {
    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
    $unit = strtoupper($unit);

    if ($unit == "K") {
      return ($miles * 1.609344);
    } else if ($unit == "N") {
      return ($miles * 0.8684);
    } else {
      return $miles;
    }
  }
}

function find_all_requests($mechanic_id) {
	global $connection;

	$query= "SELECT * FROM requests WHERE mechanic_id= $mechanic_id AND status= 'waiting' ";
	$request_set= mysqli_query($connection, $query);
	confirm_query($request_set);

	if($request_set) {
		return $request_set;
	} else { return null; }

}

function find_accepted_requests($mechanic_id) {
	global $connection;

	$query= "SELECT * FROM requests WHERE mechanic_id= $mechanic_id AND status= 'accepted' ";
	$request_set= mysqli_query($connection, $query);
	confirm_query($request_set);

	if($request_set) {
		return $request_set;
	} else { return null; }

}

function find_user_request($user_id) {
	global $connection;

	$query= "SELECT * FROM requests WHERE user_id= $user_id ";
	$request_set= mysqli_query($connection, $query);
	confirm_query($request_set);

	if($request_set) {
		return $request_set;
	} else { return null; }	
}

function find_name_by_id($table_name, $id) {
	global $connection;

	$query= "SELECT name FROM $table_name WHERE id= $id ";
	$request_set= mysqli_query($connection, $query);
	confirm_query($request_set);

	if($request= mysqli_fetch_assoc($request_set)) {
		return $request['name'];
	} else { return null; }	
}

function find_mechanic_by_id($mechanic_id) {
global $connection;

	$query= "SELECT * FROM mechanics WHERE id= $mechanic_id LIMIT 1 ";
	$request_set= mysqli_query($connection, $query);
	confirm_query($request_set);

	if($request= mysqli_fetch_assoc($request_set)) {
		return $request;
	} else { return null; }	
}

function find_user_by_id($user_id) {
global $connection;

	$query= "SELECT * FROM users WHERE id= $user_id LIMIT 1 ";
	$request_set= mysqli_query($connection, $query);
	confirm_query($request_set);

	if($request= mysqli_fetch_assoc($request_set)) {
		return $request;
	} else { return null; }	
}


function send_sms($message, $contact) {
$params = array(
    'credentials' => array(
        'key' => 'AKIAILSMQW26G5VQCBSA',
        'secret' => '/84+SojRYEGPlpOLVqPRKmtZqXAKO5Owxo2/vmnd',
    ),
    'region' => 'us-west-1', // < your aws from SNS Topic region
    'version' => 'latest'
);
$sns = new \Aws\Sns\SnsClient($params);

$msgattributes = [
        'AWS.SNS.SMS.SenderID' => [
            'DataType' => 'String',
            'StringValue' => 'Klassroom',
        ],
        'AWS.SNS.SMS.SMSType' => [
            'DataType' => 'String',
            'StringValue' => 'Transactional',
        ]
    ];
//Transactional
    $payload = array(
        'Message' => $message,
        'PhoneNumber' => $contact,
        'MessageAttributes' => $msgattributes
    );

    $result=$sns->publish($payload);
}

?>