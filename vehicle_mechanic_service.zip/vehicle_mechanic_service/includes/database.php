<?php
$servername = "localhost";
$username = "id2051508_vehicle_corp";
$password = "password";
$database = "id2051508_vehicle_service";

// Create connection
$connection = new mysqli($servername, $username, $password, $database);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

?> 
