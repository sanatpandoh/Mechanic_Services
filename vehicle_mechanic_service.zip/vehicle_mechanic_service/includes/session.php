<?php 
session_start();

function message() {
	if( isset($_SESSION["message"]) ) {
		$output= nl2br(htmlentities($_SESSION["message"]));

//clear message after use
$_SESSION["message"]=null;
return $output;
	}
}

function errors() {
	if( isset($_SESSION["errors"]) ) {
		//since erros is totally under our control so no need to use to html entities function
$errors= $_SESSION["errors"];
//clear message after use
$_SESSION["errors"]=null;
return $errors;
	}
}

?>